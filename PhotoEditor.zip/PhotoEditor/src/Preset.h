#pragma once
#include "Image.h"
#include <string>
#include <vector>

struct FilterPreset {
    std::string name = "Custom Filter";
    float brightness = 0, contrast = 0, saturation = 0, hue = 0, exposure = 0;
    float gamma = 1.0f;
    bool grayscale = false, sepia = false, invert = false;
    float blur = 0;
    float sharpen = 0;
    float vignette = 0;
};

namespace Preset {
    bool loadFilter(const std::string& path, FilterPreset& out, std::string& error);
    bool loadPlugin(const std::string& path, std::vector<FilterPreset>& out, std::string& error);
    void apply(const FilterPreset& preset, const Image& src, Image& dst);
}
