#pragma once
#include <vector>
#include <cstdint>
#include <string>
#include <algorithm>
#include <cmath>

// Simple RGBA8 image buffer used throughout the editor.
struct Image {
    int width = 0;
    int height = 0;
    int channels = 4; // always normalized to RGBA internally
    std::vector<uint8_t> pixels; // size = width*height*4

    bool empty() const { return width == 0 || height == 0 || pixels.empty(); }

    void allocate(int w, int h) {
        width = w;
        height = h;
        channels = 4;
        pixels.assign((size_t)w * h * 4, 0);
    }

    inline uint8_t* at(int x, int y) {
        return &pixels[((size_t)y * width + x) * 4];
    }
    inline const uint8_t* at(int x, int y) const {
        return &pixels[((size_t)y * width + x) * 4];
    }

    Image clone() const {
        Image copy;
        copy.width = width;
        copy.height = height;
        copy.channels = channels;
        copy.pixels = pixels;
        return copy;
    }
};

inline uint8_t clampByte(int v) {
    return (uint8_t)std::min(255, std::max(0, v));
}

inline uint8_t clampByteF(float v) {
    return (uint8_t)std::min(255.0f, std::max(0.0f, v));
}
