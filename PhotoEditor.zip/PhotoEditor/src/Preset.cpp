#include "Preset.h"
#include "Editor.h"
#include <fstream>
#include <algorithm>
#include <cctype>
#include <stdexcept>

namespace {
    std::string trim(const std::string& s) {
        size_t a = s.find_first_not_of(" \t\r\n");
        if (a == std::string::npos) return "";
        size_t b = s.find_last_not_of(" \t\r\n");
        return s.substr(a, b - a + 1);
    }

    void applyKeyValue(FilterPreset& p, const std::string& key, const std::string& value) {
        std::string k = key;
        std::transform(k.begin(), k.end(), k.begin(), [](unsigned char c) { return std::tolower(c); });
        if (k == "name")            p.name = value;
        else if (k == "brightness") p.brightness = std::stof(value);
        else if (k == "contrast")   p.contrast = std::stof(value);
        else if (k == "saturation") p.saturation = std::stof(value);
        else if (k == "hue")        p.hue = std::stof(value);
        else if (k == "exposure")   p.exposure = std::stof(value);
        else if (k == "gamma")      p.gamma = std::stof(value);
        else if (k == "grayscale")  p.grayscale = std::stoi(value) != 0;
        else if (k == "sepia")      p.sepia = std::stoi(value) != 0;
        else if (k == "invert")     p.invert = std::stoi(value) != 0;
        else if (k == "blur")       p.blur = std::stof(value);
        else if (k == "sharpen")    p.sharpen = std::stof(value);
        else if (k == "vignette")   p.vignette = std::stof(value);
    }
}

namespace Preset {

bool loadFilter(const std::string& path, FilterPreset& out, std::string& error) {
    std::ifstream file(path);
    if (!file.is_open()) { error = "Could not open file: " + path; return false; }
    out = FilterPreset{};
    std::string line;
    try {
        while (std::getline(file, line)) {
            line = trim(line);
            if (line.empty() || line[0] == '#' || line[0] == '[') continue;
            size_t eq = line.find('=');
            if (eq == std::string::npos) continue;
            applyKeyValue(out, trim(line.substr(0, eq)), trim(line.substr(eq + 1)));
        }
    } catch (const std::exception& e) {
        error = std::string("Malformed filter file (") + e.what() + ")";
        return false;
    }
    return true;
}

bool loadPlugin(const std::string& path, std::vector<FilterPreset>& out, std::string& error) {
    std::ifstream file(path);
    if (!file.is_open()) { error = "Could not open file: " + path; return false; }
    out.clear();
    std::string line;
    FilterPreset* current = nullptr;
    try {
        while (std::getline(file, line)) {
            line = trim(line);
            if (line.empty() || line[0] == '#') continue;
            if (line.front() == '[' && line.back() == ']') {
                out.push_back(FilterPreset{});
                current = &out.back();
                current->name = line.substr(1, line.size() - 2);
                continue;
            }
            if (!current) continue;
            size_t eq = line.find('=');
            if (eq == std::string::npos) continue;
            applyKeyValue(*current, trim(line.substr(0, eq)), trim(line.substr(eq + 1)));
        }
    } catch (const std::exception& e) {
        error = std::string("Malformed plugin file (") + e.what() + ")";
        return false;
    }
    if (out.empty()) { error = "Plugin file contains no [Sections]"; return false; }
    return true;
}

void apply(const FilterPreset& p, const Image& src, Image& dst) {
    Image result = src;
    if (p.brightness != 0) Editor::adjustBrightness(result, result, p.brightness);
    if (p.contrast != 0)   Editor::adjustContrast(result, result, p.contrast);
    if (p.saturation != 0) Editor::adjustSaturation(result, result, p.saturation);
    if (p.hue != 0)         Editor::adjustHue(result, result, p.hue);
    if (p.exposure != 0)    Editor::adjustExposure(result, result, p.exposure);
    if (p.gamma != 1.0f)    Editor::adjustGamma(result, result, p.gamma);
    if (p.grayscale) Editor::toGrayscale(result, result);
    if (p.sepia) Editor::toSepia(result, result);
    if (p.invert) Editor::invertColors(result, result);
    if (p.blur > 0) Editor::gaussianBlur(result, result, p.blur);
    if (p.sharpen > 0) Editor::sharpen(result, result, p.sharpen);
    if (p.vignette > 0) Editor::vignette(result, result, p.vignette);
    dst = std::move(result);
}

} // namespace Preset
