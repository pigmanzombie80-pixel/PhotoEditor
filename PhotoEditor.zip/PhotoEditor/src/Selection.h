#pragma once
#include <vector>
#include <utility>
#include <algorithm>
#include <cmath>
#include <cstdint>

// A pixel-precision selection mask covering the canvas. When inactive
// (the normal state now that there are no selection tools in the UI),
// tools treat the whole active layer as selected. Kept as infrastructure
// so Cut/Copy/Paste and paint-tool clipping have a single code path.
class Selection {
public:
    int width = 0, height = 0;
    bool active = false;
    std::vector<uint8_t> mask;

    void resize(int w, int h) {
        width = w; height = h;
        mask.assign((size_t)w * h, 0);
        active = false;
    }

    void clear() {
        std::fill(mask.begin(), mask.end(), 0);
        active = false;
    }

    bool contains(int x, int y) const {
        if (!active) return true;
        if (x < 0 || y < 0 || x >= width || y >= height) return false;
        return mask[(size_t)y * width + x] != 0;
    }

    void boundingBox(int& x, int& y, int& w, int& h) const {
        if (!active) { x = 0; y = 0; w = width; h = height; return; }
        int minX = width, minY = height, maxX = -1, maxY = -1;
        for (int yy = 0; yy < height; yy++)
            for (int xx = 0; xx < width; xx++)
                if (mask[(size_t)yy * width + xx]) {
                    minX = std::min(minX, xx); maxX = std::max(maxX, xx);
                    minY = std::min(minY, yy); maxY = std::max(maxY, yy);
                }
        if (maxX < minX) { x = 0; y = 0; w = 0; h = 0; return; }
        x = minX; y = minY; w = maxX - minX + 1; h = maxY - minY + 1;
    }
};
