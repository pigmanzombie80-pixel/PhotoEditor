#pragma once
#include "Layer.h"
#include <vector>

struct EditorState {
    std::vector<Layer> layers;
    int activeLayer = 0;
};

class History {
public:
    void reset(const EditorState& initial) {
        undoStack.clear();
        redoStack.clear();
        current = initial;
    }

    const EditorState& get() const { return current; }

    void commit(const EditorState& newState) {
        undoStack.push_back(current);
        if (undoStack.size() > maxHistory) undoStack.erase(undoStack.begin());
        redoStack.clear();
        current = newState;
    }

    bool canUndo() const { return !undoStack.empty(); }
    bool canRedo() const { return !redoStack.empty(); }

    void undo() {
        if (!canUndo()) return;
        redoStack.push_back(current);
        current = undoStack.back();
        undoStack.pop_back();
    }

    void redo() {
        if (!canRedo()) return;
        undoStack.push_back(current);
        current = redoStack.back();
        redoStack.pop_back();
    }

private:
    EditorState current;
    std::vector<EditorState> undoStack;
    std::vector<EditorState> redoStack;
    size_t maxHistory = 15;
};
