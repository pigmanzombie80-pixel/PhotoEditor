#include "ImageIO.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"
#include <algorithm>
#include <cctype>

namespace ImageIO {

std::string extensionOf(const std::string& path) {
    size_t dot = path.find_last_of('.');
    if (dot == std::string::npos) return "";
    std::string ext = path.substr(dot + 1);
    std::transform(ext.begin(), ext.end(), ext.begin(), [](unsigned char c){ return std::tolower(c); });
    return ext;
}

bool load(const std::string& path, Image& outImage, std::string& error) {
    int w, h, channelsInFile;
    unsigned char* data = stbi_load(path.c_str(), &w, &h, &channelsInFile, 4);
    if (!data) {
        error = stbi_failure_reason() ? stbi_failure_reason() : "Unknown error loading image";
        return false;
    }
    outImage.width = w;
    outImage.height = h;
    outImage.channels = 4;
    outImage.pixels.assign(data, data + (size_t)w * h * 4);
    stbi_image_free(data);
    return true;
}

bool savePNG(const std::string& path, const Image& img, std::string& error) {
    if (img.empty()) { error = "Cannot save empty image"; return false; }
    int stride = img.width * 4;
    int result = stbi_write_png(path.c_str(), img.width, img.height, 4, img.pixels.data(), stride);
    if (!result) { error = "Failed to write PNG file"; return false; }
    return true;
}

bool saveJPG(const std::string& path, const Image& img, int quality, std::string& error) {
    if (img.empty()) { error = "Cannot save empty image"; return false; }
    quality = std::min(100, std::max(1, quality));
    int result = stbi_write_jpg(path.c_str(), img.width, img.height, 4, img.pixels.data(), quality);
    if (!result) { error = "Failed to write JPG file"; return false; }
    return true;
}

} // namespace ImageIO
