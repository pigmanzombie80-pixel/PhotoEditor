#pragma once
#include "Image.h"
#include <string>
#include <vector>

struct Layer {
    Image pixels;
    std::string name = "Layer";
    bool visible = true;
    float opacity = 1.0f;

    Layer() = default;
    Layer(int w, int h, const std::string& n) : name(n) {
        pixels.allocate(w, h);
    }
};

inline Image compositeLayers(const std::vector<Layer>& layers, int width, int height) {
    Image out;
    out.allocate(width, height);
    for (const auto& layer : layers) {
        if (!layer.visible || layer.opacity <= 0.0f) continue;
        size_t n = (size_t)width * height;
        for (size_t i = 0; i < n; i++) {
            const uint8_t* s = &layer.pixels.pixels[i * 4];
            uint8_t* d = &out.pixels[i * 4];
            float srcA = (s[3] / 255.0f) * layer.opacity;
            if (srcA <= 0.0f) continue;
            float dstA = d[3] / 255.0f;
            float outA = srcA + dstA * (1.0f - srcA);
            if (outA <= 0.0001f) { d[0] = d[1] = d[2] = d[3] = 0; continue; }
            for (int c = 0; c < 3; c++) {
                float srcC = s[c] / 255.0f;
                float dstC = d[c] / 255.0f;
                float outC = (srcC * srcA + dstC * dstA * (1.0f - srcA)) / outA;
                d[c] = clampByteF(outC * 255.0f);
            }
            d[3] = clampByteF(outA * 255.0f);
        }
    }
    return out;
}

inline Image flattenOntoBackground(const Image& src, uint8_t bgR, uint8_t bgG, uint8_t bgB) {
    Image out;
    out.allocate(src.width, src.height);
    size_t n = (size_t)src.width * src.height;
    for (size_t i = 0; i < n; i++) {
        const uint8_t* s = &src.pixels[i * 4];
        uint8_t* d = &out.pixels[i * 4];
        float a = s[3] / 255.0f;
        d[0] = clampByteF(s[0] * a + bgR * (1 - a));
        d[1] = clampByteF(s[1] * a + bgG * (1 - a));
        d[2] = clampByteF(s[2] * a + bgB * (1 - a));
        d[3] = 255;
    }
    return out;
}
