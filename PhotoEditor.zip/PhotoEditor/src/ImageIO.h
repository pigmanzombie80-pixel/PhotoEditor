#pragma once
#include "Image.h"
#include <string>

namespace ImageIO {
    bool load(const std::string& path, Image& outImage, std::string& error);
    bool savePNG(const std::string& path, const Image& img, std::string& error);
    bool saveJPG(const std::string& path, const Image& img, int quality, std::string& error);
    std::string extensionOf(const std::string& path);
}
