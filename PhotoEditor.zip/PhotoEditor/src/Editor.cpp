#include "Editor.h"
#define STB_IMAGE_RESIZE_IMPLEMENTATION
#include "stb_image_resize2.h"
#include <cmath>
#include <algorithm>
#include <vector>

namespace {
    constexpr float PI = 3.14159265358979323846f;

    void rgbToHsv(float r, float g, float b, float& h, float& s, float& v) {
        float mx = std::max({r, g, b});
        float mn = std::min({r, g, b});
        float d = mx - mn;
        v = mx;
        s = (mx <= 0.0f) ? 0.0f : d / mx;
        if (d < 1e-6f) { h = 0.0f; return; }
        if (mx == r)      h = 60.0f * fmodf(((g - b) / d), 6.0f);
        else if (mx == g) h = 60.0f * (((b - r) / d) + 2.0f);
        else              h = 60.0f * (((r - g) / d) + 4.0f);
        if (h < 0.0f) h += 360.0f;
    }

    void hsvToRgb(float h, float s, float v, float& r, float& g, float& b) {
        float c = v * s;
        float x = c * (1.0f - fabsf(fmodf(h / 60.0f, 2.0f) - 1.0f));
        float m = v - c;
        float rr, gg, bb;
        if      (h < 60.0f)  { rr = c; gg = x; bb = 0; }
        else if (h < 120.0f) { rr = x; gg = c; bb = 0; }
        else if (h < 180.0f) { rr = 0; gg = c; bb = x; }
        else if (h < 240.0f) { rr = 0; gg = x; bb = c; }
        else if (h < 300.0f) { rr = x; gg = 0; bb = c; }
        else                 { rr = c; gg = 0; bb = x; }
        r = rr + m; g = gg + m; b = bb + m;
    }
}

namespace Editor {

void adjustBrightness(const Image& src, Image& dst, float brightness) {
    if (dst.width != src.width || dst.height != src.height) dst.allocate(src.width, src.height);
    int offset = (int)std::round(brightness * 2.55f);
    size_t n = (size_t)src.width * src.height;
    for (size_t i = 0; i < n; i++) {
        const uint8_t* s = &src.pixels[i * 4];
        uint8_t* d = &dst.pixels[i * 4];
        d[0] = clampByte(s[0] + offset);
        d[1] = clampByte(s[1] + offset);
        d[2] = clampByte(s[2] + offset);
        d[3] = s[3];
    }
}

void adjustContrast(const Image& src, Image& dst, float contrast) {
    if (dst.width != src.width || dst.height != src.height) dst.allocate(src.width, src.height);
    float c = std::clamp(contrast, -100.0f, 100.0f);
    float factor = (259.0f * (c + 255.0f)) / (255.0f * (259.0f - c));
    size_t n = (size_t)src.width * src.height;
    for (size_t i = 0; i < n; i++) {
        const uint8_t* s = &src.pixels[i * 4];
        uint8_t* d = &dst.pixels[i * 4];
        d[0] = clampByteF(factor * (s[0] - 128.0f) + 128.0f);
        d[1] = clampByteF(factor * (s[1] - 128.0f) + 128.0f);
        d[2] = clampByteF(factor * (s[2] - 128.0f) + 128.0f);
        d[3] = s[3];
    }
}

void adjustSaturation(const Image& src, Image& dst, float saturation) {
    if (dst.width != src.width || dst.height != src.height) dst.allocate(src.width, src.height);
    float scale = 1.0f + std::clamp(saturation, -100.0f, 100.0f) / 100.0f;
    size_t n = (size_t)src.width * src.height;
    for (size_t i = 0; i < n; i++) {
        const uint8_t* s = &src.pixels[i * 4];
        uint8_t* d = &dst.pixels[i * 4];
        float r = s[0] / 255.0f, g = s[1] / 255.0f, b = s[2] / 255.0f;
        float gray = 0.299f * r + 0.587f * g + 0.114f * b;
        r = gray + (r - gray) * scale;
        g = gray + (g - gray) * scale;
        b = gray + (b - gray) * scale;
        d[0] = clampByteF(r * 255.0f);
        d[1] = clampByteF(g * 255.0f);
        d[2] = clampByteF(b * 255.0f);
        d[3] = s[3];
    }
}

void adjustHue(const Image& src, Image& dst, float hueDegrees) {
    if (dst.width != src.width || dst.height != src.height) dst.allocate(src.width, src.height);
    size_t n = (size_t)src.width * src.height;
    for (size_t i = 0; i < n; i++) {
        const uint8_t* s = &src.pixels[i * 4];
        uint8_t* d = &dst.pixels[i * 4];
        float h, sVal, v;
        rgbToHsv(s[0] / 255.0f, s[1] / 255.0f, s[2] / 255.0f, h, sVal, v);
        h = fmodf(h + hueDegrees, 360.0f);
        if (h < 0.0f) h += 360.0f;
        float r, g, b;
        hsvToRgb(h, sVal, v, r, g, b);
        d[0] = clampByteF(r * 255.0f);
        d[1] = clampByteF(g * 255.0f);
        d[2] = clampByteF(b * 255.0f);
        d[3] = s[3];
    }
}

void adjustExposure(const Image& src, Image& dst, float stops) {
    if (dst.width != src.width || dst.height != src.height) dst.allocate(src.width, src.height);
    float factor = powf(2.0f, std::clamp(stops, -3.0f, 3.0f));
    size_t n = (size_t)src.width * src.height;
    for (size_t i = 0; i < n; i++) {
        const uint8_t* s = &src.pixels[i * 4];
        uint8_t* d = &dst.pixels[i * 4];
        d[0] = clampByteF(s[0] * factor);
        d[1] = clampByteF(s[1] * factor);
        d[2] = clampByteF(s[2] * factor);
        d[3] = s[3];
    }
}

void adjustGamma(const Image& src, Image& dst, float gamma) {
    if (dst.width != src.width || dst.height != src.height) dst.allocate(src.width, src.height);
    gamma = std::max(0.01f, gamma);
    float invGamma = 1.0f / gamma;
    uint8_t lut[256];
    for (int i = 0; i < 256; i++) lut[i] = clampByteF(powf(i / 255.0f, invGamma) * 255.0f);
    size_t n = (size_t)src.width * src.height;
    for (size_t i = 0; i < n; i++) {
        const uint8_t* s = &src.pixels[i * 4];
        uint8_t* d = &dst.pixels[i * 4];
        d[0] = lut[s[0]]; d[1] = lut[s[1]]; d[2] = lut[s[2]]; d[3] = s[3];
    }
}

void toGrayscale(const Image& src, Image& dst) {
    if (dst.width != src.width || dst.height != src.height) dst.allocate(src.width, src.height);
    size_t n = (size_t)src.width * src.height;
    for (size_t i = 0; i < n; i++) {
        const uint8_t* s = &src.pixels[i * 4];
        uint8_t* d = &dst.pixels[i * 4];
        uint8_t gray = clampByteF(0.299f * s[0] + 0.587f * s[1] + 0.114f * s[2]);
        d[0] = d[1] = d[2] = gray;
        d[3] = s[3];
    }
}

void toSepia(const Image& src, Image& dst) {
    if (dst.width != src.width || dst.height != src.height) dst.allocate(src.width, src.height);
    size_t n = (size_t)src.width * src.height;
    for (size_t i = 0; i < n; i++) {
        const uint8_t* s = &src.pixels[i * 4];
        uint8_t* d = &dst.pixels[i * 4];
        float r = s[0], g = s[1], b = s[2];
        d[0] = clampByteF(0.393f * r + 0.769f * g + 0.189f * b);
        d[1] = clampByteF(0.349f * r + 0.686f * g + 0.168f * b);
        d[2] = clampByteF(0.272f * r + 0.534f * g + 0.131f * b);
        d[3] = s[3];
    }
}

void invertColors(const Image& src, Image& dst) {
    if (dst.width != src.width || dst.height != src.height) dst.allocate(src.width, src.height);
    size_t n = (size_t)src.width * src.height;
    for (size_t i = 0; i < n; i++) {
        const uint8_t* s = &src.pixels[i * 4];
        uint8_t* d = &dst.pixels[i * 4];
        d[0] = 255 - s[0]; d[1] = 255 - s[1]; d[2] = 255 - s[2]; d[3] = s[3];
    }
}

void boxBlur(const Image& src, Image& dst, int radius) {
    radius = std::clamp(radius, 1, 25);
    if (dst.width != src.width || dst.height != src.height) dst.allocate(src.width, src.height);
    int w = src.width, h = src.height;
    std::vector<uint8_t> tmp((size_t)w * h * 4);
    for (int y = 0; y < h; y++) {
        for (int x = 0; x < w; x++) {
            int sum[4] = {0,0,0,0};
            int count = 0;
            for (int dx = -radius; dx <= radius; dx++) {
                int sx = std::clamp(x + dx, 0, w - 1);
                const uint8_t* p = src.at(sx, y);
                sum[0]+=p[0]; sum[1]+=p[1]; sum[2]+=p[2]; sum[3]+=p[3];
                count++;
            }
            uint8_t* t = &tmp[((size_t)y * w + x) * 4];
            t[0]=sum[0]/count; t[1]=sum[1]/count; t[2]=sum[2]/count; t[3]=sum[3]/count;
        }
    }
    for (int y = 0; y < h; y++) {
        for (int x = 0; x < w; x++) {
            int sum[4] = {0,0,0,0};
            int count = 0;
            for (int dy = -radius; dy <= radius; dy++) {
                int sy = std::clamp(y + dy, 0, h - 1);
                const uint8_t* p = &tmp[((size_t)sy * w + x) * 4];
                sum[0]+=p[0]; sum[1]+=p[1]; sum[2]+=p[2]; sum[3]+=p[3];
                count++;
            }
            uint8_t* d = dst.at(x, y);
            d[0]=sum[0]/count; d[1]=sum[1]/count; d[2]=sum[2]/count; d[3]=sum[3]/count;
        }
    }
}

void gaussianBlur(const Image& src, Image& dst, float sigma) {
    sigma = std::clamp(sigma, 0.1f, 15.0f);
    int radius = std::max(1, (int)std::ceil(sigma * 3.0f));
    std::vector<float> kernel(radius * 2 + 1);
    float sum = 0.0f;
    for (int i = -radius; i <= radius; i++) {
        float v = expf(-(i * i) / (2.0f * sigma * sigma));
        kernel[i + radius] = v;
        sum += v;
    }
    for (auto& v : kernel) v /= sum;

    if (dst.width != src.width || dst.height != src.height) dst.allocate(src.width, src.height);
    int w = src.width, h = src.height;
    std::vector<float> tmp((size_t)w * h * 4);
    for (int y = 0; y < h; y++) {
        for (int x = 0; x < w; x++) {
            float acc[4] = {0,0,0,0};
            for (int k = -radius; k <= radius; k++) {
                int sx = std::clamp(x + k, 0, w - 1);
                const uint8_t* p = src.at(sx, y);
                float kw = kernel[k + radius];
                acc[0]+=p[0]*kw; acc[1]+=p[1]*kw; acc[2]+=p[2]*kw; acc[3]+=p[3]*kw;
            }
            float* t = &tmp[((size_t)y * w + x) * 4];
            t[0]=acc[0]; t[1]=acc[1]; t[2]=acc[2]; t[3]=acc[3];
        }
    }
    for (int y = 0; y < h; y++) {
        for (int x = 0; x < w; x++) {
            float acc[4] = {0,0,0,0};
            for (int k = -radius; k <= radius; k++) {
                int sy = std::clamp(y + k, 0, h - 1);
                float* p = &tmp[((size_t)sy * w + x) * 4];
                float kw = kernel[k + radius];
                acc[0]+=p[0]*kw; acc[1]+=p[1]*kw; acc[2]+=p[2]*kw; acc[3]+=p[3]*kw;
            }
            uint8_t* d = dst.at(x, y);
            d[0]=clampByteF(acc[0]); d[1]=clampByteF(acc[1]); d[2]=clampByteF(acc[2]); d[3]=clampByteF(acc[3]);
        }
    }
}

void sharpen(const Image& src, Image& dst, float amount) {
    amount = std::clamp(amount, 0.0f, 3.0f);
    Image blurred;
    gaussianBlur(src, blurred, 2.0f);
    if (dst.width != src.width || dst.height != src.height) dst.allocate(src.width, src.height);
    size_t n = (size_t)src.width * src.height;
    for (size_t i = 0; i < n; i++) {
        const uint8_t* s = &src.pixels[i * 4];
        const uint8_t* b = &blurred.pixels[i * 4];
        uint8_t* d = &dst.pixels[i * 4];
        for (int c = 0; c < 3; c++) {
            float highFreq = s[c] - b[c];
            d[c] = clampByteF(s[c] + highFreq * amount);
        }
        d[3] = s[3];
    }
}

void vignette(const Image& src, Image& dst, float strength) {
    strength = std::clamp(strength, 0.0f, 1.0f);
    if (dst.width != src.width || dst.height != src.height) dst.allocate(src.width, src.height);
    int w = src.width, h = src.height;
    float cx = w / 2.0f, cy = h / 2.0f;
    float maxDist = std::sqrt(cx * cx + cy * cy);
    for (int y = 0; y < h; y++) {
        for (int x = 0; x < w; x++) {
            const uint8_t* s = src.at(x, y);
            uint8_t* d = dst.at(x, y);
            float dist = std::sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy)) / maxDist;
            float falloff = 1.0f - strength * (dist * dist);
            falloff = std::clamp(falloff, 0.0f, 1.0f);
            d[0] = clampByteF(s[0] * falloff);
            d[1] = clampByteF(s[1] * falloff);
            d[2] = clampByteF(s[2] * falloff);
            d[3] = s[3];
        }
    }
}

void flipHorizontal(const Image& src, Image& dst) {
    Image out; out.allocate(src.width, src.height);
    for (int y = 0; y < src.height; y++)
        for (int x = 0; x < src.width; x++)
            std::copy(src.at(x, y), src.at(x, y) + 4, out.at(src.width - 1 - x, y));
    dst = std::move(out);
}

void flipVertical(const Image& src, Image& dst) {
    Image out; out.allocate(src.width, src.height);
    for (int y = 0; y < src.height; y++)
        for (int x = 0; x < src.width; x++)
            std::copy(src.at(x, y), src.at(x, y) + 4, out.at(x, src.height - 1 - y));
    dst = std::move(out);
}

void rotate90(const Image& src, Image& dst) {
    Image out; out.allocate(src.height, src.width);
    for (int y = 0; y < src.height; y++)
        for (int x = 0; x < src.width; x++)
            std::copy(src.at(x, y), src.at(x, y) + 4, out.at(src.height - 1 - y, x));
    dst = std::move(out);
}

void rotate180(const Image& src, Image& dst) {
    Image out; out.allocate(src.width, src.height);
    for (int y = 0; y < src.height; y++)
        for (int x = 0; x < src.width; x++)
            std::copy(src.at(x, y), src.at(x, y) + 4, out.at(src.width - 1 - x, src.height - 1 - y));
    dst = std::move(out);
}

void rotate270(const Image& src, Image& dst) {
    Image out; out.allocate(src.height, src.width);
    for (int y = 0; y < src.height; y++)
        for (int x = 0; x < src.width; x++)
            std::copy(src.at(x, y), src.at(x, y) + 4, out.at(y, src.width - 1 - x));
    dst = std::move(out);
}

void rotateArbitrary(const Image& src, Image& dst, float degrees) {
    float rad = degrees * PI / 180.0f;
    float cosA = cosf(-rad), sinA = sinf(-rad);
    int w = src.width, h = src.height;
    float cornersX[4] = {0, (float)w, 0, (float)w};
    float cornersY[4] = {0, 0, (float)h, (float)h};
    float minX = 1e9f, maxX = -1e9f, minY = 1e9f, maxY = -1e9f;
    float cx0 = w / 2.0f, cy0 = h / 2.0f;
    for (int i = 0; i < 4; i++) {
        float x = cornersX[i] - cx0, y = cornersY[i] - cy0;
        float rx = x * cosf(rad) - y * sinf(rad);
        float ry = x * sinf(rad) + y * cosf(rad);
        minX = std::min(minX, rx); maxX = std::max(maxX, rx);
        minY = std::min(minY, ry); maxY = std::max(maxY, ry);
    }
    int newW = (int)std::ceil(maxX - minX);
    int newH = (int)std::ceil(maxY - minY);
    Image out; out.allocate(newW, newH);
    float ncx = newW / 2.0f, ncy = newH / 2.0f;
    for (int y = 0; y < newH; y++) {
        for (int x = 0; x < newW; x++) {
            float dx = x - ncx, dy = y - ncy;
            float sx = dx * cosA - dy * sinA + cx0;
            float sy = dx * sinA + dy * cosA + cy0;
            uint8_t* d = out.at(x, y);
            if (sx >= 0 && sx < w - 1 && sy >= 0 && sy < h - 1) {
                int ix = (int)sx, iy = (int)sy;
                float fx = sx - ix, fy = sy - iy;
                const uint8_t* p00 = src.at(ix, iy);
                const uint8_t* p10 = src.at(ix + 1, iy);
                const uint8_t* p01 = src.at(ix, iy + 1);
                const uint8_t* p11 = src.at(ix + 1, iy + 1);
                for (int c = 0; c < 4; c++) {
                    float top = p00[c] * (1 - fx) + p10[c] * fx;
                    float bot = p01[c] * (1 - fx) + p11[c] * fx;
                    d[c] = clampByteF(top * (1 - fy) + bot * fy);
                }
            } else {
                d[0]=d[1]=d[2]=d[3]=0;
            }
        }
    }
    dst = std::move(out);
}

void resize(const Image& src, Image& dst, int newWidth, int newHeight) {
    newWidth = std::max(1, newWidth);
    newHeight = std::max(1, newHeight);
    Image out; out.allocate(newWidth, newHeight);
    stbir_resize_uint8_linear(
        src.pixels.data(), src.width, src.height, 0,
        out.pixels.data(), newWidth, newHeight, 0,
        STBIR_RGBA
    );
    dst = std::move(out);
}

void crop(const Image& src, Image& dst, int x, int y, int w, int h) {
    x = std::clamp(x, 0, src.width - 1);
    y = std::clamp(y, 0, src.height - 1);
    w = std::clamp(w, 1, src.width - x);
    h = std::clamp(h, 1, src.height - y);
    Image out; out.allocate(w, h);
    for (int yy = 0; yy < h; yy++)
        for (int xx = 0; xx < w; xx++)
            std::copy(src.at(x + xx, y + yy), src.at(x + xx, y + yy) + 4, out.at(xx, yy));
    dst = std::move(out);
}

} // namespace Editor
