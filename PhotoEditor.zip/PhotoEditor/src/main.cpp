#include "imgui.h"
#include "backends/imgui_impl_glfw.h"
#include "backends/imgui_impl_opengl3.h"
#include <GLFW/glfw3.h>

#include "Image.h"
#include "ImageIO.h"
#include "Editor.h"
#include "Layer.h"
#include "Selection.h"
#include "PaintTools.h"
#include "Preset.h"
#include "History.h"
#include "tinyfiledialogs.h"

#ifndef GL_CLAMP_TO_EDGE
#define GL_CLAMP_TO_EDGE 0x812F
#endif

#include <string>
#include <vector>
#include <map>
#include <functional>
#include <cstdio>
#include <algorithm>
#include <cmath>

enum class Tool {
    None, Brush, Eraser, Bucket, Eyedropper, Crop
};

// ---------------------------------------------------------------------------
// A slider that also supports double-click to type an exact value.
// ---------------------------------------------------------------------------
static bool sliderDbl(const char* label, float* value, float minV, float maxV, const char* format = "%.2f") {
    bool changed = ImGui::SliderFloat(label, value, minV, maxV, format);
    if (ImGui::IsItemHovered() && ImGui::IsMouseDoubleClicked(ImGuiMouseButton_Left)) {
        ImGui::OpenPopup(label);
    }
    if (ImGui::BeginPopup(label)) {
        ImGui::Text("Enter exact value:");
        ImGui::SetNextItemWidth(140);
        if (ImGui::InputFloat("##val", value, 0.0f, 0.0f, format, ImGuiInputTextFlags_EnterReturnsTrue)) {
            *value = std::clamp(*value, minV, maxV);
            changed = true;
            ImGui::CloseCurrentPopup();
        }
        *value = std::clamp(*value, minV, maxV);
        ImGui::EndPopup();
    }
    return changed;
}

// ---------------------------------------------------------------------------
// GPU texture helper
// ---------------------------------------------------------------------------
struct GLTexture {
    GLuint id = 0;
    int width = 0, height = 0;

    void upload(const Image& img) {
        if (img.empty()) return;
        if (id == 0) glGenTextures(1, &id);
        glBindTexture(GL_TEXTURE_2D, id);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, img.width, img.height, 0, GL_RGBA, GL_UNSIGNED_BYTE, img.pixels.data());
        width = img.width; height = img.height;
    }
};

// An imported filter/plugin entry with an adjustable application "amount"
// (0-200%, blended against the original) and a running apply counter.
struct ImportedFilterEntry {
    FilterPreset preset;
    float amount = 1.0f; // 1.0 = 100% strength
    int applyCount = 0;
};

// Default values filters/tools reset to after being applied, so sliders
// don't drift and are ready for the next fresh application.
namespace Defaults {
    constexpr float BlurSigma = 3.0f;
    constexpr float SharpenAmt = 1.0f;
    constexpr float VignetteAmt = 0.4f;
    constexpr int DocW = 1920;
    constexpr int DocH = 1080;
}

// ---------------------------------------------------------------------------
// Application state
// ---------------------------------------------------------------------------
struct AppState {
    History history;
    int canvasW = 0, canvasH = 0;
    Selection selection; // kept for paint-tool clipping infrastructure; no dedicated UI tool sets it anymore
    GLTexture texture;
    std::string currentPath;
    bool hasPath = false;
    std::string statusMessage = "Ready.";
    bool imageLoaded = false;

    float brightness = 0, contrast = 0, saturation = 0, hue = 0, exposure = 0;
    float gamma = 1.0f;

    Tool currentTool = Tool::None;
    ImVec2 dragStart{0,0}, dragEnd{0,0};
    bool dragging = false;

    float brushRadius = 12.0f;
    float eraserRadius = 16.0f;
    float eraserStrength = 1.0f;
    PaintTools::Color brushColor{ 30, 30, 30, 255 };
    Image strokeBuffer;
    bool strokeActive = false;
    ImVec2 lastPaintPos{0,0};

    float bucketTolerance = 30.0f;

    Image clipboard;
    bool hasClipboard = false;
    int clipboardX = 0, clipboardY = 0;

    int resizeW = 0, resizeH = 0;
    bool lockAspect = true;
    float rotateDegrees = 0.0f;

    // Built-in filter parameters (moved out of static locals so they can be reset after Apply)
    float blurSigma = Defaults::BlurSigma;
    float sharpenAmt = Defaults::SharpenAmt;
    float vignetteAmt = Defaults::VignetteAmt;
    std::map<std::string, int> filterApplyCounts; // "Grayscale" -> times applied, etc.

    std::vector<ImportedFilterEntry> customFilters; // from Filters > Import...
    std::vector<ImportedFilterEntry> pluginFilters; // from Plugins > Import...

    bool showNewDocModal = false;
    int newDocW = Defaults::DocW, newDocH = Defaults::DocH;

    // ---- Document lifecycle ----

    void newDocument(int w, int h) {
        EditorState state;
        Layer bg(w, h, "Background");
        for (size_t i = 0; i < bg.pixels.pixels.size(); i += 4) {
            bg.pixels.pixels[i + 0] = 255;
            bg.pixels.pixels[i + 1] = 255;
            bg.pixels.pixels[i + 2] = 255;
            bg.pixels.pixels[i + 3] = 255;
        }
        state.layers.push_back(bg);
        state.activeLayer = 0;
        history.reset(state);
        canvasW = w; canvasH = h;
        selection.resize(w, h);
        currentPath.clear(); hasPath = false;
        imageLoaded = true;
        resetAdjustments();
        resizeW = w; resizeH = h;
        refreshTextureFromHistory();
        statusMessage = "New " + std::to_string(w) + "x" + std::to_string(h) + " document created";
    }

    void loadFromDisk(const std::string& path) {
        Image img;
        std::string err;
        if (!ImageIO::load(path, img, err)) {
            statusMessage = "Failed to open: " + err;
            return;
        }
        EditorState state;
        Layer bg(img.width, img.height, "Background");
        bg.pixels = img;
        state.layers.push_back(bg);
        state.activeLayer = 0;
        history.reset(state);
        canvasW = img.width; canvasH = img.height;
        selection.resize(canvasW, canvasH);
        currentPath = path; hasPath = true;
        imageLoaded = true;
        resetAdjustments();
        resizeW = canvasW; resizeH = canvasH;
        refreshTextureFromHistory();
        statusMessage = "Opened " + path;
    }

    void save() {
        if (!hasPath) { saveAs(); return; }
        std::string ext = ImageIO::extensionOf(currentPath);
        Image flat = compositeLayers(history.get().layers, canvasW, canvasH);
        std::string err;
        bool ok;
        if (ext == "jpg" || ext == "jpeg") {
            Image opaque = flattenOntoBackground(flat, 255, 255, 255);
            ok = ImageIO::saveJPG(currentPath, opaque, 92, err);
        } else {
            ok = ImageIO::savePNG(currentPath, flat, err);
        }
        statusMessage = ok ? ("Saved " + currentPath) : ("Save failed: " + err);
    }

    void saveAs() {
        const char* filters[] = { "*.png", "*.jpg", "*.jpeg" };
        const char* result = tinyfd_saveFileDialog("Save As",
            currentPath.empty() ? "untitled.png" : currentPath.c_str(), 3, filters, "Image files");
        if (!result) return;
        currentPath = result;
        hasPath = true;
        save();
    }

    // ---- Rendering helpers ----

    void refreshTextureFromHistory() {
        texture.upload(compositeLayers(history.get().layers, canvasW, canvasH));
    }

    void resetAdjustments() {
        brightness = contrast = saturation = hue = exposure = 0;
        gamma = 1.0f;
    }

    void refreshPreview() {
        if (!imageLoaded) return;
        EditorState preview = history.get();
        Image& L = preview.layers[preview.activeLayer].pixels;
        if (brightness != 0) Editor::adjustBrightness(L, L, brightness);
        if (contrast != 0)   Editor::adjustContrast(L, L, contrast);
        if (saturation != 0) Editor::adjustSaturation(L, L, saturation);
        if (hue != 0)         Editor::adjustHue(L, L, hue);
        if (exposure != 0)    Editor::adjustExposure(L, L, exposure);
        if (gamma != 1.0f)    Editor::adjustGamma(L, L, gamma);
        texture.upload(compositeLayers(preview.layers, canvasW, canvasH));
    }

    void commitAdjustments() {
        if (brightness == 0 && contrast == 0 && saturation == 0 && hue == 0 && exposure == 0 && gamma == 1.0f) return;
        EditorState newState = history.get();
        Image& L = newState.layers[newState.activeLayer].pixels;
        if (brightness != 0) Editor::adjustBrightness(L, L, brightness);
        if (contrast != 0)   Editor::adjustContrast(L, L, contrast);
        if (saturation != 0) Editor::adjustSaturation(L, L, saturation);
        if (hue != 0)         Editor::adjustHue(L, L, hue);
        if (exposure != 0)    Editor::adjustExposure(L, L, exposure);
        if (gamma != 1.0f)    Editor::adjustGamma(L, L, gamma);
        history.commit(newState);
        resetAdjustments();
        refreshTextureFromHistory();
        statusMessage = "Applied manual adjustments";
    }

    // Applies a one-shot filter to the active layer, commits, and tracks how
    // many times that named filter has been applied so far.
    void applyLayerFilter(const std::string& name, const std::function<void(const Image&, Image&)>& op) {
        EditorState newState = history.get();
        Image& L = newState.layers[newState.activeLayer].pixels;
        Image result;
        op(L, result);
        L = result;
        history.commit(newState);
        refreshTextureFromHistory();
        filterApplyCounts[name]++;
        statusMessage = name + " applied (" + std::to_string(filterApplyCounts[name]) + "x total on this layer's history)";
    }

    // Applies an imported preset blended by `amount` (0..2, i.e. 0-200%)
    // against the original layer content, then commits.
    void applyImportedPreset(ImportedFilterEntry& entry) {
        EditorState newState = history.get();
        Image& L = newState.layers[newState.activeLayer].pixels;
        Image processed;
        Preset::apply(entry.preset, L, processed);
        Image blended = L;
        float amt = std::clamp(entry.amount, 0.0f, 2.0f);
        size_t n = (size_t)L.width * L.height;
        for (size_t i = 0; i < n; i++) {
            uint8_t* d = &blended.pixels[i * 4];
            const uint8_t* orig = &L.pixels[i * 4];
            const uint8_t* proc = &processed.pixels[i * 4];
            for (int c = 0; c < 3; c++) {
                float v = orig[c] + (proc[c] - (float)orig[c]) * amt;
                d[c] = clampByteF(v);
            }
            d[3] = orig[3];
        }
        L = blended;
        history.commit(newState);
        refreshTextureFromHistory();
        entry.applyCount++;
        statusMessage = entry.preset.name + " applied at " + std::to_string((int)(amt * 100)) + "% (" + std::to_string(entry.applyCount) + "x total)";
    }

    void applyTransformAll(const std::function<void(const Image&, Image&)>& op) {
        EditorState newState = history.get();
        for (auto& L : newState.layers) {
            Image result;
            op(L.pixels, result);
            L.pixels = result;
        }
        canvasW = newState.layers[0].pixels.width;
        canvasH = newState.layers[0].pixels.height;
        selection.resize(canvasW, canvasH);
        history.commit(newState);
        resizeW = canvasW; resizeH = canvasH;
        refreshTextureFromHistory();
    }

    void applyResizeAll(int w, int h) {
        EditorState newState = history.get();
        for (auto& L : newState.layers) {
            Image result;
            Editor::resize(L.pixels, result, w, h);
            L.pixels = result;
        }
        canvasW = w; canvasH = h;
        selection.resize(w, h);
        history.commit(newState);
        refreshTextureFromHistory();
        statusMessage = "Resized to " + std::to_string(w) + "x" + std::to_string(h);
    }

    void applyCropAll(int x, int y, int w, int h) {
        EditorState newState = history.get();
        for (auto& L : newState.layers) {
            Image result;
            Editor::crop(L.pixels, result, x, y, w, h);
            L.pixels = result;
        }
        canvasW = w; canvasH = h;
        selection.resize(w, h);
        history.commit(newState);
        resizeW = w; resizeH = h;
        refreshTextureFromHistory();
        statusMessage = "Cropped to " + std::to_string(w) + "x" + std::to_string(h);
    }

    void addLayer() {
        if (canvasW == 0) return;
        EditorState state = history.get();
        Layer newLayer(canvasW, canvasH, "Layer " + std::to_string(state.layers.size() + 1));
        state.layers.push_back(newLayer);
        state.activeLayer = (int)state.layers.size() - 1;
        history.commit(state);
        refreshTextureFromHistory();
        statusMessage = "Added new layer";
    }

    // ---- Clipboard (operates on the whole active layer since there are no selection tools) ----

    void copySelection() {
        if (!imageLoaded) return;
        int x, y, w, h;
        selection.boundingBox(x, y, w, h); // full canvas when no selection is active
        if (w <= 0 || h <= 0) return;
        const Image& L = history.get().layers[history.get().activeLayer].pixels;
        clipboard.allocate(w, h);
        for (int yy = 0; yy < h; yy++)
            for (int xx = 0; xx < w; xx++) {
                uint8_t* d = clipboard.at(xx, yy);
                const uint8_t* s = L.at(x + xx, y + yy);
                d[0] = s[0]; d[1] = s[1]; d[2] = s[2]; d[3] = s[3];
            }
        clipboardX = x; clipboardY = y;
        hasClipboard = true;
        statusMessage = "Copied active layer";
    }

    void cutSelection() {
        if (!imageLoaded) return;
        int x, y, w, h;
        selection.boundingBox(x, y, w, h);
        if (w <= 0 || h <= 0) return;
        copySelection();
        EditorState newState = history.get();
        Image& L = newState.layers[newState.activeLayer].pixels;
        for (int yy = 0; yy < h; yy++)
            for (int xx = 0; xx < w; xx++) {
                uint8_t* p = L.at(x + xx, y + yy);
                p[0] = p[1] = p[2] = p[3] = 0;
            }
        history.commit(newState);
        refreshTextureFromHistory();
        statusMessage = "Cut active layer content";
    }

    void pasteClipboard() {
        if (!hasClipboard || !imageLoaded) return;
        EditorState newState = history.get();
        Layer newLayer(canvasW, canvasH, "Pasted");
        for (int yy = 0; yy < clipboard.height; yy++)
            for (int xx = 0; xx < clipboard.width; xx++) {
                int dx = clipboardX + xx, dy = clipboardY + yy;
                if (dx < 0 || dy < 0 || dx >= canvasW || dy >= canvasH) continue;
                const uint8_t* s = clipboard.at(xx, yy);
                uint8_t* d = newLayer.pixels.at(dx, dy);
                d[0] = s[0]; d[1] = s[1]; d[2] = s[2]; d[3] = s[3];
            }
        newState.layers.push_back(newLayer);
        newState.activeLayer = (int)newState.layers.size() - 1;
        history.commit(newState);
        refreshTextureFromHistory();
        statusMessage = "Pasted as new layer";
    }

    // ---- Undo / redo ----

    void syncFromHistory() {
        const EditorState& s = history.get();
        if (!s.layers.empty()) { canvasW = s.layers[0].pixels.width; canvasH = s.layers[0].pixels.height; }
        selection.resize(canvasW, canvasH);
        resetAdjustments();
        resizeW = canvasW; resizeH = canvasH;
        refreshTextureFromHistory();
    }

    void undo() { if (!history.canUndo()) return; history.undo(); syncFromHistory(); statusMessage = "Undo"; }
    void redo() { if (!history.canRedo()) return; history.redo(); syncFromHistory(); statusMessage = "Redo"; }
};

static void glfwErrorCallback(int error, const char* description) {
    fprintf(stderr, "GLFW Error %d: %s\n", error, description);
}

static bool pickOpenFile(std::string& outPath) {
    const char* filters[] = { "*.png", "*.jpg", "*.jpeg" };
    const char* result = tinyfd_openFileDialog("Open Image", "", 3, filters, "Image files (png, jpg)", 0);
    if (!result) return false;
    outPath = result;
    return true;
}

// ---------------------------------------------------------------------------
// Top menu bar
// ---------------------------------------------------------------------------
static void drawMenuBar(AppState& app) {
    ImGuiIO& io = ImGui::GetIO();
    bool ctrl = io.KeyCtrl;
    bool shift = io.KeyShift;

    if (ctrl && !shift && ImGui::IsKeyPressed(ImGuiKey_F, false)) ImGui::OpenPopup("FileMenuPopup");
    if (ctrl && ImGui::IsKeyPressed(ImGuiKey_E, false)) ImGui::OpenPopup("EditMenuPopup");
    if (ctrl && shift && ImGui::IsKeyPressed(ImGuiKey_F, false)) ImGui::OpenPopup("FiltersMenuPopup");
    if (ctrl && ImGui::IsKeyPressed(ImGuiKey_P, false)) ImGui::OpenPopup("PluginsMenuPopup");
    if (ctrl && ImGui::IsKeyPressed(ImGuiKey_H, false)) ImGui::OpenPopup("HelpMenuPopup");

    if (ctrl && ImGui::IsKeyPressed(ImGuiKey_N, false)) app.showNewDocModal = true;
    if (ctrl && ImGui::IsKeyPressed(ImGuiKey_O, false)) { std::string p; if (pickOpenFile(p)) app.loadFromDisk(p); }
    if (ctrl && !shift && ImGui::IsKeyPressed(ImGuiKey_S, false)) app.save();
    if (ctrl && shift && ImGui::IsKeyPressed(ImGuiKey_S, false)) app.saveAs();
    if (ctrl && ImGui::IsKeyPressed(ImGuiKey_Z, false)) app.undo();
    if (ctrl && ImGui::IsKeyPressed(ImGuiKey_Y, false)) app.redo();
    if (ctrl && ImGui::IsKeyPressed(ImGuiKey_X, false)) app.cutSelection();
    if (ctrl && ImGui::IsKeyPressed(ImGuiKey_C, false)) app.copySelection();
    if (ctrl && ImGui::IsKeyPressed(ImGuiKey_V, false)) app.pasteClipboard();

    ImGui::BeginGroup();
    if (ImGui::Button("File")) ImGui::OpenPopup("FileMenuPopup");
    ImGui::SameLine();
    if (ImGui::Button("Edit")) ImGui::OpenPopup("EditMenuPopup");
    ImGui::SameLine();
    if (ImGui::Button("Filters")) ImGui::OpenPopup("FiltersMenuPopup");
    ImGui::SameLine();
    if (ImGui::Button("Plugins")) ImGui::OpenPopup("PluginsMenuPopup");
    ImGui::SameLine();
    if (ImGui::Button("Help")) ImGui::OpenPopup("HelpMenuPopup");
    ImGui::SameLine();
    ImGui::TextDisabled("|");
    ImGui::SameLine();
    // Top-bar info line: what's currently going on.
    std::string toolName;
    switch (app.currentTool) {
        case Tool::Brush: toolName = "Brush"; break;
        case Tool::Eraser: toolName = "Eraser"; break;
        case Tool::Bucket: toolName = "Paint Bucket"; break;
        case Tool::Eyedropper: toolName = "Eyedropper"; break;
        case Tool::Crop: toolName = "Crop"; break;
        default: toolName = "None"; break;
    }
    std::string fileLabel = app.hasPath ? app.currentPath : (app.imageLoaded ? "Untitled" : "No document");
    ImGui::Text("%s   |   %dx%d   |   Tool: %s", fileLabel.c_str(), app.canvasW, app.canvasH, toolName.c_str());
    ImGui::EndGroup();

    if (ImGui::BeginPopup("FileMenuPopup")) {
        if (ImGui::MenuItem("New...", "Ctrl+N")) app.showNewDocModal = true;
        if (ImGui::MenuItem("Open...", "Ctrl+O")) { std::string p; if (pickOpenFile(p)) app.loadFromDisk(p); }
        if (ImGui::MenuItem("Save", "Ctrl+S", false, app.imageLoaded)) app.save();
        if (ImGui::MenuItem("Save As...", "Ctrl+Shift+S", false, app.imageLoaded)) app.saveAs();
        ImGui::EndPopup();
    }
    if (ImGui::BeginPopup("EditMenuPopup")) {
        if (ImGui::MenuItem("Undo", "Ctrl+Z", false, app.history.canUndo())) app.undo();
        if (ImGui::MenuItem("Redo", "Ctrl+Y", false, app.history.canRedo())) app.redo();
        ImGui::Separator();
        if (ImGui::MenuItem("Cut", "Ctrl+X", false, app.imageLoaded)) app.cutSelection();
        if (ImGui::MenuItem("Copy", "Ctrl+C", false, app.imageLoaded)) app.copySelection();
        if (ImGui::MenuItem("Paste", "Ctrl+V", false, app.hasClipboard)) app.pasteClipboard();
        ImGui::EndPopup();
    }
    if (ImGui::BeginPopup("FiltersMenuPopup")) {
        if (ImGui::MenuItem("Import...")) {
            const char* filt[] = { "*.cpfilter" };
            const char* result = tinyfd_openFileDialog("Import Filter", "", 1, filt, "Custom Filter (.cpfilter)", 0);
            if (result) {
                FilterPreset p; std::string err;
                if (Preset::loadFilter(result, p, err)) {
                    app.customFilters.push_back({ p, 1.0f, 0 });
                    app.statusMessage = "Imported filter: " + p.name + " (see bottom bar)";
                } else {
                    app.statusMessage = "Import failed: " + err;
                }
            }
        }
        ImGui::EndPopup();
    }
    if (ImGui::BeginPopup("PluginsMenuPopup")) {
        if (ImGui::MenuItem("Import...")) {
            const char* filt[] = { "*.cpplugin" };
            const char* result = tinyfd_openFileDialog("Import Plugin", "", 1, filt, "Custom Plugin (.cpplugin)", 0);
            if (result) {
                std::vector<FilterPreset> presets; std::string err;
                if (Preset::loadPlugin(result, presets, err)) {
                    for (auto& p : presets) app.pluginFilters.push_back({ p, 1.0f, 0 });
                    app.statusMessage = "Imported plugin with " + std::to_string(presets.size()) + " filter(s) (see bottom bar)";
                } else {
                    app.statusMessage = "Import failed: " + err;
                }
            }
        }
        ImGui::EndPopup();
    }
    if (ImGui::BeginPopup("HelpMenuPopup")) {
        if (ImGui::MenuItem("Keyboard Shortcuts")) ImGui::OpenPopup("ShortcutsHelp");
        if (ImGui::MenuItem("Custom Filter/Plugin Format")) ImGui::OpenPopup("FormatHelp");
        if (ImGui::MenuItem("About")) ImGui::OpenPopup("AboutHelp");
        ImGui::EndPopup();
    }

    if (ImGui::BeginPopupModal("ShortcutsHelp", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::Text("Menus:  Ctrl+F File   Ctrl+E Edit   Ctrl+Shift+F Filters   Ctrl+P Plugins   Ctrl+H Help");
        ImGui::Separator();
        ImGui::Text("New: Ctrl+N   Open: Ctrl+O   Save: Ctrl+S   Save As: Ctrl+Shift+S");
        ImGui::Text("Undo: Ctrl+Z  Redo: Ctrl+Y   Cut: Ctrl+X   Copy: Ctrl+C   Paste: Ctrl+V");
        ImGui::Text("Double-click any slider to type an exact value.");
        if (ImGui::Button("Close")) ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }
    if (ImGui::BeginPopupModal("FormatHelp", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::TextUnformatted(
            "A .cpfilter file is plain text, one setting per line:\n\n"
            "  NAME=My Filter\n"
            "  brightness=20      (-100..100)\n"
            "  contrast=15        (-100..100)\n"
            "  saturation=-10     (-100..100)\n"
            "  hue=0              (-180..180)\n"
            "  exposure=0         (-3..3)\n"
            "  gamma=1.0          (0.1..3.0)\n"
            "  grayscale=0/1\n"
            "  sepia=0/1\n"
            "  invert=0/1\n"
            "  blur=0             (gaussian sigma)\n"
            "  sharpen=0\n"
            "  vignette=0         (0..1)\n\n"
            "A .cpplugin file bundles several filters as [Sections]:\n\n"
            "  [Vintage Look]\n"
            "  brightness=10\n"
            "  sepia=1\n"
            "  vignette=0.4\n\n"
            "  [Cool Tone]\n"
            "  hue=200\n"
            "  saturation=-10\n\n"
            "Imported filters appear at the bottom of the window with an\n"
            "Amount slider (0-200%) that blends the effect against the\n"
            "original before applying."
        );
        if (ImGui::Button("Close")) ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }
    if (ImGui::BeginPopupModal("AboutHelp", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::Text("Lightweight Photo Editor");
        ImGui::Text("Built with Dear ImGui, GLFW, OpenGL, and stb_image.");
        if (ImGui::Button("Close")) ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }
}

static void drawNewDocumentModal(AppState& app) {
    if (app.showNewDocModal) {
        ImGui::OpenPopup("New Document");
        app.showNewDocModal = false;
    }
    if (ImGui::BeginPopupModal("New Document", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::InputInt("Width", &app.newDocW);
        ImGui::InputInt("Height", &app.newDocH);
        app.newDocW = std::max(1, app.newDocW);
        app.newDocH = std::max(1, app.newDocH);
        if (ImGui::Button("1080p", ImVec2(80,0))) { app.newDocW = 1920; app.newDocH = 1080; }
        ImGui::SameLine();
        if (ImGui::Button("4K", ImVec2(80,0))) { app.newDocW = 3840; app.newDocH = 2160; }
        ImGui::SameLine();
        if (ImGui::Button("Square", ImVec2(80,0))) { app.newDocW = 1080; app.newDocH = 1080; }
        if (ImGui::Button("Create", ImVec2(120, 0))) {
            app.newDocument(app.newDocW, app.newDocH);
            ImGui::CloseCurrentPopup();
        }
        ImGui::SameLine();
        if (ImGui::Button("Cancel", ImVec2(120, 0))) ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }
}

// ---------------------------------------------------------------------------
// Right-hand tools panel: collapsible sections
// ---------------------------------------------------------------------------
static void drawToolButton(AppState& app, const char* label, Tool tool) {
    bool selected = (app.currentTool == tool);
    if (selected) ImGui::PushStyleColor(ImGuiCol_Button, ImGui::GetStyleColorVec4(ImGuiCol_ButtonActive));
    if (ImGui::Button(label, ImVec2(-1, 0))) {
        app.currentTool = selected ? Tool::None : tool;
        app.dragging = false;
    }
    if (selected) ImGui::PopStyleColor();
}

static void drawToolsSection(AppState& app) {
    if (!ImGui::CollapsingHeader("Tools", ImGuiTreeNodeFlags_DefaultOpen)) return;
    drawToolButton(app, "Brush", Tool::Brush);
    drawToolButton(app, "Eraser", Tool::Eraser);
    drawToolButton(app, "Paint Bucket", Tool::Bucket);
    drawToolButton(app, "Eyedropper", Tool::Eyedropper);
    drawToolButton(app, "Crop", Tool::Crop);

    switch (app.currentTool) {
    case Tool::Brush: {
        sliderDbl("Brush size", &app.brushRadius, 1, 80, "%.0f px");
        float col[4] = { app.brushColor.r / 255.0f, app.brushColor.g / 255.0f, app.brushColor.b / 255.0f, app.brushColor.a / 255.0f };
        if (ImGui::ColorEdit4("Color", col)) {
            app.brushColor = { (uint8_t)(col[0]*255), (uint8_t)(col[1]*255), (uint8_t)(col[2]*255), (uint8_t)(col[3]*255) };
        }
        break;
    }
    case Tool::Eraser:
        sliderDbl("Eraser size", &app.eraserRadius, 1, 80, "%.0f px");
        sliderDbl("Strength", &app.eraserStrength, 0.05f, 1.0f);
        ImGui::TextDisabled("Erased areas turn transparent (checkerboard).");
        break;
    case Tool::Bucket: {
        sliderDbl("Tolerance", &app.bucketTolerance, 0, 100, "%.0f");
        float col[4] = { app.brushColor.r / 255.0f, app.brushColor.g / 255.0f, app.brushColor.b / 255.0f, app.brushColor.a / 255.0f };
        if (ImGui::ColorEdit4("Fill color", col)) {
            app.brushColor = { (uint8_t)(col[0]*255), (uint8_t)(col[1]*255), (uint8_t)(col[2]*255), (uint8_t)(col[3]*255) };
        }
        break;
    }
    case Tool::Eyedropper: {
        ImGui::Text("Picked color:");
        float col[4] = { app.brushColor.r / 255.0f, app.brushColor.g / 255.0f, app.brushColor.b / 255.0f, app.brushColor.a / 255.0f };
        ImGui::ColorButton("##pickedColor", ImVec4(col[0], col[1], col[2], col[3]), 0, ImVec2(60, 30));
        ImGui::SameLine();
        ImGui::Text("RGBA(%d,%d,%d,%d)", app.brushColor.r, app.brushColor.g, app.brushColor.b, app.brushColor.a);
        ImGui::TextDisabled("Click on the canvas to pick a color.\nSwitches to Brush automatically after picking.");
        break;
    }
    case Tool::Crop: {
        int x = (int)std::min(app.dragStart.x, app.dragEnd.x);
        int y = (int)std::min(app.dragStart.y, app.dragEnd.y);
        int w = (int)std::abs(app.dragEnd.x - app.dragStart.x);
        int h = (int)std::abs(app.dragEnd.y - app.dragStart.y);
        ImGui::Text("Selection: %d,%d  %dx%d", x, y, w, h);
        if (ImGui::Button("Apply Crop", ImVec2(-1, 0)) && w > 0 && h > 0) {
            app.applyCropAll(x, y, w, h);
            app.currentTool = Tool::None;
        }
        break;
    }
    default:
        ImGui::TextDisabled("Select a tool above to see its options.");
        break;
    }
}

static void drawAdjustmentsSection(AppState& app) {
    if (!ImGui::CollapsingHeader("Adjustments (active layer)", ImGuiTreeNodeFlags_DefaultOpen)) return;
    bool changed = false;
    changed |= sliderDbl("Brightness", &app.brightness, -100, 100);
    changed |= sliderDbl("Contrast", &app.contrast, -100, 100);
    changed |= sliderDbl("Saturation", &app.saturation, -100, 100);
    changed |= sliderDbl("Hue", &app.hue, -180, 180);
    changed |= sliderDbl("Exposure", &app.exposure, -3, 3);
    changed |= sliderDbl("Gamma", &app.gamma, 0.1f, 3.0f);
    if (changed) app.refreshPreview();
    if (ImGui::Button("Apply", ImVec2(-1, 0))) app.commitAdjustments();
    if (ImGui::Button("Reset Sliders", ImVec2(-1, 0))) { app.resetAdjustments(); app.refreshPreview(); }
}

static void drawFiltersSection(AppState& app) {
    if (!ImGui::CollapsingHeader("Filters (active layer)")) return;

    auto countLabel = [&](const char* base, const char* key) {
        int c = app.filterApplyCounts.count(key) ? app.filterApplyCounts[key] : 0;
        static char buf[64];
        if (c > 0) snprintf(buf, sizeof(buf), "%s (%dx)", base, c);
        else snprintf(buf, sizeof(buf), "%s", base);
        return buf;
    };

    if (ImGui::Button(countLabel("Grayscale", "Grayscale"), ImVec2(-1, 0)))
        app.applyLayerFilter("Grayscale", Editor::toGrayscale);
    if (ImGui::Button(countLabel("Sepia", "Sepia"), ImVec2(-1, 0)))
        app.applyLayerFilter("Sepia", Editor::toSepia);
    if (ImGui::Button(countLabel("Invert", "Invert"), ImVec2(-1, 0)))
        app.applyLayerFilter("Invert", Editor::invertColors);

    sliderDbl("Blur sigma", &app.blurSigma, 0.1f, 15.0f);
    if (ImGui::Button(countLabel("Apply Blur", "Blur"), ImVec2(-1, 0))) {
        float sigma = app.blurSigma;
        app.applyLayerFilter("Blur", [sigma](const Image& s, Image& d) { Editor::gaussianBlur(s, d, sigma); });
        app.blurSigma = Defaults::BlurSigma; // reset so it doesn't drift after applying
    }

    sliderDbl("Sharpen amount", &app.sharpenAmt, 0.0f, 3.0f);
    if (ImGui::Button(countLabel("Apply Sharpen", "Sharpen"), ImVec2(-1, 0))) {
        float amt = app.sharpenAmt;
        app.applyLayerFilter("Sharpen", [amt](const Image& s, Image& d) { Editor::sharpen(s, d, amt); });
        app.sharpenAmt = Defaults::SharpenAmt;
    }

    sliderDbl("Vignette", &app.vignetteAmt, 0.0f, 1.0f);
    if (ImGui::Button(countLabel("Apply Vignette", "Vignette"), ImVec2(-1, 0))) {
        float amt = app.vignetteAmt;
        app.applyLayerFilter("Vignette", [amt](const Image& s, Image& d) { Editor::vignette(s, d, amt); });
        app.vignetteAmt = Defaults::VignetteAmt;
    }
}

// Small icon-style button: fixed square size with a short glyph/abbreviation
// and a tooltip explaining what it does. (Dear ImGui's default font doesn't
// include arrow/unicode glyphs without adding a font dependency, so these
// use compact ASCII abbreviations styled as a toolbar instead of true icons.)
static bool iconButton(const char* glyph, const char* tooltip) {
    bool clicked = ImGui::Button(glyph, ImVec2(52, 36));
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", tooltip);
    return clicked;
}

static void drawTransformSection(AppState& app) {
    if (!ImGui::CollapsingHeader("Transform (whole canvas)")) return;

    ImGui::TextDisabled("Flip / Rotate:");
    if (iconButton("FlipH", "Flip Horizontal")) app.applyTransformAll(Editor::flipHorizontal);
    ImGui::SameLine();
    if (iconButton("FlipV", "Flip Vertical")) app.applyTransformAll(Editor::flipVertical);
    ImGui::SameLine();
    if (iconButton("90 CW", "Rotate 90 deg clockwise")) app.applyTransformAll(Editor::rotate90);
    if (iconButton("180", "Rotate 180 deg")) app.applyTransformAll(Editor::rotate180);
    ImGui::SameLine();
    if (iconButton("90 CCW", "Rotate 90 deg counter-clockwise")) app.applyTransformAll(Editor::rotate270);

    sliderDbl("Free rotate", &app.rotateDegrees, -180, 180);
    if (ImGui::Button("Apply Rotation", ImVec2(-1, 0))) {
        float deg = app.rotateDegrees;
        app.applyTransformAll([deg](const Image& s, Image& d) { Editor::rotateArbitrary(s, d, deg); });
        app.rotateDegrees = 0;
    }

    ImGui::SeparatorText("Resize");
    ImGui::Checkbox("Lock aspect ratio", &app.lockAspect);
    float aspect = (app.canvasW == 0) ? 1.0f : (float)app.canvasW / app.canvasH;
    if (ImGui::InputInt("Width", &app.resizeW) && app.lockAspect)
        app.resizeH = std::max(1, (int)(app.resizeW / aspect));
    if (ImGui::InputInt("Height", &app.resizeH) && app.lockAspect)
        app.resizeW = std::max(1, (int)(app.resizeH * aspect));
    if (ImGui::Button("Apply Resize", ImVec2(-1, 0))) app.applyResizeAll(app.resizeW, app.resizeH);
}

static void drawLayersSection(AppState& app) {
    if (!ImGui::CollapsingHeader("Layers", ImGuiTreeNodeFlags_DefaultOpen)) return;
    if (ImGui::Button("+ Add Layer", ImVec2(-1, 0))) app.addLayer();

    // IMPORTANT: read via const reference, do NOT copy the whole document
    // (with all layer pixel buffers) just to draw the panel every frame --
    // that was the cause of the sluggish/unresponsive layer controls.
    const EditorState& cstate = app.history.get();
    int n = (int)cstate.layers.size();

    int toggleVisIndex = -1, selectIndex = -1;
    int opacityLiveIndex = -1; float opacityLiveValue = 0.0f;
    bool opacityCommit = false; int opacityCommitIndex = -1;
    int moveUpIndex = -1, moveDownIndex = -1, deleteIndex = -1;

    for (int i = n - 1; i >= 0; i--) {
        ImGui::PushID(i);
        const Layer& L = cstate.layers[i];
        bool visible = L.visible;
        bool isActive = (i == cstate.activeLayer);

        if (ImGui::Checkbox("##vis", &visible)) toggleVisIndex = i;
        ImGui::SameLine();
        if (ImGui::Selectable(L.name.c_str(), isActive, 0, ImVec2(110, 0))) selectIndex = i;

        float opacity = L.opacity;
        ImGui::SetNextItemWidth(130);
        if (sliderDbl("##op", &opacity, 0.0f, 1.0f, "Opacity %.2f")) { opacityLiveIndex = i; opacityLiveValue = opacity; }
        if (ImGui::IsItemDeactivatedAfterEdit()) { opacityCommit = true; opacityCommitIndex = i; }

        ImGui::SameLine();
        if (ImGui::SmallButton("Up") && i < n - 1) moveUpIndex = i;
        ImGui::SameLine();
        if (ImGui::SmallButton("Dn") && i > 0) moveDownIndex = i;
        ImGui::SameLine();
        ImGui::BeginDisabled(n <= 1);
        if (ImGui::SmallButton("Del")) deleteIndex = i;
        ImGui::EndDisabled();

        ImGui::PopID();
    }

    bool needCommit = (toggleVisIndex >= 0 || selectIndex >= 0 || moveUpIndex >= 0 || moveDownIndex >= 0 || deleteIndex >= 0 || opacityCommit);
    bool needPreviewOnly = (opacityLiveIndex >= 0 && !opacityCommit);

    if (needCommit || needPreviewOnly) {
        EditorState state = cstate; // only copy now, when an interaction actually happened
        if (toggleVisIndex >= 0) state.layers[toggleVisIndex].visible = !state.layers[toggleVisIndex].visible;
        if (selectIndex >= 0) state.activeLayer = selectIndex;
        if (opacityLiveIndex >= 0) state.layers[opacityLiveIndex].opacity = opacityLiveValue;
        if (moveUpIndex >= 0) {
            std::swap(state.layers[moveUpIndex], state.layers[moveUpIndex + 1]);
            if (state.activeLayer == moveUpIndex) state.activeLayer = moveUpIndex + 1;
            else if (state.activeLayer == moveUpIndex + 1) state.activeLayer = moveUpIndex;
        }
        if (moveDownIndex >= 0) {
            std::swap(state.layers[moveDownIndex], state.layers[moveDownIndex - 1]);
            if (state.activeLayer == moveDownIndex) state.activeLayer = moveDownIndex - 1;
            else if (state.activeLayer == moveDownIndex - 1) state.activeLayer = moveDownIndex;
        }
        if (deleteIndex >= 0) {
            state.layers.erase(state.layers.begin() + deleteIndex);
            if (state.activeLayer >= (int)state.layers.size()) state.activeLayer = (int)state.layers.size() - 1;
        }

        if (needCommit) {
            app.history.commit(state);
            app.refreshTextureFromHistory();
        } else {
            app.texture.upload(compositeLayers(state.layers, app.canvasW, app.canvasH));
        }
    }
}

static void drawHistorySection(AppState& app) {
    if (!ImGui::CollapsingHeader("History")) return;
    ImGui::BeginDisabled(!app.history.canUndo());
    if (ImGui::Button("Undo", ImVec2(-1, 0))) app.undo();
    ImGui::EndDisabled();
    ImGui::BeginDisabled(!app.history.canRedo());
    if (ImGui::Button("Redo", ImVec2(-1, 0))) app.redo();
    ImGui::EndDisabled();
}

// ---------------------------------------------------------------------------
// Bottom bar: status info + imported filters/plugins with adjustable amount
// ---------------------------------------------------------------------------
static void drawImportedEntry(AppState& app, ImportedFilterEntry& entry, int uid) {
    ImGui::PushID(uid);
    ImGui::BeginGroup();
    ImGui::TextUnformatted(entry.preset.name.c_str());
    ImGui::SetNextItemWidth(140);
    float amountPct = entry.amount * 100.0f;
    if (sliderDbl("##amt", &amountPct, 0.0f, 200.0f, "%.0f%%")) entry.amount = amountPct / 100.0f;
    if (ImGui::Button("Apply", ImVec2(140, 0))) app.applyImportedPreset(entry);
    if (entry.applyCount > 0) { ImGui::SameLine(); ImGui::TextDisabled("(%dx)", entry.applyCount); }
    ImGui::EndGroup();
    ImGui::PopID();
}

static void drawBottomBar(AppState& app) {
    ImGui::Text("Status: %s", app.statusMessage.c_str());
    ImGui::Separator();

    bool anyImported = !app.customFilters.empty() || !app.pluginFilters.empty();
    if (!anyImported) {
        ImGui::TextDisabled("No custom filters/plugins imported yet. Use Filters > Import... or Plugins > Import...");
        return;
    }

    ImGui::BeginChild("ImportedStrip", ImVec2(0, 0), false, ImGuiWindowFlags_HorizontalScrollbar);
    int uid = 0;
    if (!app.customFilters.empty()) {
        ImGui::TextDisabled("Imported Filters:");
        ImGui::SameLine();
        for (auto& entry : app.customFilters) {
            drawImportedEntry(app, entry, uid++);
            ImGui::SameLine();
        }
        ImGui::NewLine();
    }
    if (!app.pluginFilters.empty()) {
        ImGui::TextDisabled("Imported Plugins:");
        ImGui::SameLine();
        for (auto& entry : app.pluginFilters) {
            drawImportedEntry(app, entry, uid++);
            ImGui::SameLine();
        }
        ImGui::NewLine();
    }
    ImGui::EndChild();
}

// ---------------------------------------------------------------------------
// Left workspace: canvas with checkerboard (transparency) background and
// tool-specific mouse interaction.
// ---------------------------------------------------------------------------
static void drawCheckerboard(ImDrawList* dl, ImVec2 pos, ImVec2 size, float cell = 12.0f) {
    ImU32 c1 = IM_COL32(60, 60, 62, 255);
    ImU32 c2 = IM_COL32(45, 45, 47, 255);
    int cols = (int)std::ceil(size.x / cell);
    int rows = (int)std::ceil(size.y / cell);
    for (int r = 0; r < rows; r++) {
        for (int c = 0; c < cols; c++) {
            ImU32 col = ((r + c) % 2 == 0) ? c1 : c2;
            ImVec2 p0(pos.x + c * cell, pos.y + r * cell);
            ImVec2 p1(std::min(p0.x + cell, pos.x + size.x), std::min(p0.y + cell, pos.y + size.y));
            dl->AddRectFilled(p0, p1, col);
        }
    }
}

static void drawCanvas(AppState& app) {
    ImGui::BeginChild("canvas", ImVec2(0, 0), true, ImGuiWindowFlags_HorizontalScrollbar);
    if (!app.imageLoaded) {
        ImGui::TextDisabled("File > New or File > Open to begin editing.");
        ImGui::EndChild();
        return;
    }

    ImVec2 avail = ImGui::GetContentRegionAvail();
    float scale = std::min(avail.x / app.texture.width, avail.y / app.texture.height);
    scale = std::min(scale, 1.0f);
    ImVec2 displaySize(app.texture.width * scale, app.texture.height * scale);

    ImVec2 cursor = ImGui::GetCursorScreenPos();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    // Checkerboard behind the image so transparent (erased) areas are
    // clearly distinguishable from "painted black".
    drawCheckerboard(dl, cursor, displaySize);

    ImGui::Image((ImTextureID)(intptr_t)app.texture.id, displaySize);
    bool hovered = ImGui::IsItemHovered();
    ImGuiIO& io = ImGui::GetIO();

    auto toImageCoord = [&](ImVec2 mouse) {
        float ix = (mouse.x - cursor.x) / scale;
        float iy = (mouse.y - cursor.y) / scale;
        return ImVec2(std::clamp(ix, 0.0f, (float)app.canvasW), std::clamp(iy, 0.0f, (float)app.canvasH));
    };

    switch (app.currentTool) {
    case Tool::Brush:
    case Tool::Eraser: {
        bool isEraser = (app.currentTool == Tool::Eraser);
        int radius = isEraser ? (int)app.eraserRadius : (int)app.brushRadius;
        if (hovered && ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
            app.strokeActive = true;
            app.strokeBuffer = app.history.get().layers[app.history.get().activeLayer].pixels;
            ImVec2 p = toImageCoord(io.MousePos);
            app.lastPaintPos = p;
            if (isEraser) PaintTools::stampEraser(app.strokeBuffer, app.selection, (int)p.x, (int)p.y, radius, app.eraserStrength);
            else PaintTools::stampBrush(app.strokeBuffer, app.selection, (int)p.x, (int)p.y, radius, app.brushColor);
        }
        if (app.strokeActive && ImGui::IsMouseDown(ImGuiMouseButton_Left)) {
            ImVec2 p = toImageCoord(io.MousePos);
            float dist = std::sqrt((p.x - app.lastPaintPos.x) * (p.x - app.lastPaintPos.x) + (p.y - app.lastPaintPos.y) * (p.y - app.lastPaintPos.y));
            // Denser interpolation (radius*0.25 step) for smoother continuous strokes.
            int steps = std::max(1, (int)(dist / std::max(1.0f, radius * 0.25f)));
            for (int s = 1; s <= steps; s++) {
                float t = (float)s / steps;
                int ix = (int)(app.lastPaintPos.x + (p.x - app.lastPaintPos.x) * t);
                int iy = (int)(app.lastPaintPos.y + (p.y - app.lastPaintPos.y) * t);
                if (isEraser) PaintTools::stampEraser(app.strokeBuffer, app.selection, ix, iy, radius, app.eraserStrength);
                else PaintTools::stampBrush(app.strokeBuffer, app.selection, ix, iy, radius, app.brushColor);
            }
            app.lastPaintPos = p;
            EditorState preview = app.history.get();
            preview.layers[preview.activeLayer].pixels = app.strokeBuffer;
            app.texture.upload(compositeLayers(preview.layers, app.canvasW, app.canvasH));
        }
        if (app.strokeActive && ImGui::IsMouseReleased(ImGuiMouseButton_Left)) {
            EditorState newState = app.history.get();
            newState.layers[newState.activeLayer].pixels = app.strokeBuffer;
            app.history.commit(newState);
            app.strokeActive = false;
            app.refreshTextureFromHistory();
            app.statusMessage = isEraser ? "Erased stroke applied" : "Brush stroke applied";
        }
        break;
    }
    case Tool::Bucket: {
        if (hovered && ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
            ImVec2 p = toImageCoord(io.MousePos);
            EditorState newState = app.history.get();
            PaintTools::floodFill(newState.layers[newState.activeLayer].pixels, app.selection, (int)p.x, (int)p.y, app.brushColor, (int)app.bucketTolerance);
            app.history.commit(newState);
            app.refreshTextureFromHistory();
            app.statusMessage = "Paint bucket fill applied";
        }
        break;
    }
    case Tool::Eyedropper: {
        if (hovered && ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
            ImVec2 p = toImageCoord(io.MousePos);
            Image comp = compositeLayers(app.history.get().layers, app.canvasW, app.canvasH);
            app.brushColor = PaintTools::pickColor(comp, (int)p.x, (int)p.y);
            app.statusMessage = "Picked color from canvas -- switched to Brush";
            app.currentTool = Tool::Brush; // immediate, visible feedback that it worked
        }
        break;
    }
    case Tool::Crop: {
        if (hovered && ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
            app.dragging = true;
            app.dragStart = toImageCoord(io.MousePos);
            app.dragEnd = app.dragStart;
        }
        if (app.dragging && ImGui::IsMouseDown(ImGuiMouseButton_Left)) app.dragEnd = toImageCoord(io.MousePos);
        if (app.dragging && ImGui::IsMouseReleased(ImGuiMouseButton_Left)) app.dragging = false;
        {
            ImVec2 p0(cursor.x + app.dragStart.x * scale, cursor.y + app.dragStart.y * scale);
            ImVec2 p1(cursor.x + app.dragEnd.x * scale, cursor.y + app.dragEnd.y * scale);
            dl->AddRect(p0, p1, IM_COL32(255, 200, 0, 255), 0, 0, 2.0f);
            dl->AddRectFilled(p0, p1, IM_COL32(255, 200, 0, 40));
        }
        break;
    }
    default: break;
    }

    ImGui::EndChild();
}

int main(int, char**) {
    glfwSetErrorCallback(glfwErrorCallback);
    if (!glfwInit()) return 1;

    const char* glsl_version = "#version 130";
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
    glfwWindowHint(GLFW_MAXIMIZED, GLFW_TRUE); // open maximized ("full screen") by default

    GLFWwindow* window = glfwCreateWindow(1400, 850, "Lightweight Photo Editor", nullptr, nullptr);
    if (!window) return 1;
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    ImGui::StyleColorsDark();

    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init(glsl_version);

    AppState app;
    const float toolsPanelWidth = 380.0f;
    const float topBarHeight = 40.0f;
    const float bottomBarHeight = 130.0f;

    while (!glfwWindowShouldClose(window)) {
        glfwPollEvents();

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();

        ImGuiViewport* viewport = ImGui::GetMainViewport();

        ImGui::SetNextWindowPos(viewport->WorkPos);
        ImGui::SetNextWindowSize(ImVec2(viewport->WorkSize.x, topBarHeight));
        ImGui::Begin("TopBar", nullptr, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize |
            ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar);
        drawMenuBar(app);
        drawNewDocumentModal(app);
        ImGui::End();

        float middleHeight = viewport->WorkSize.y - topBarHeight - bottomBarHeight;

        ImGui::SetNextWindowPos(ImVec2(viewport->WorkPos.x, viewport->WorkPos.y + topBarHeight));
        ImGui::SetNextWindowSize(ImVec2(viewport->WorkSize.x - toolsPanelWidth, middleHeight));
        ImGui::Begin("Workspace", nullptr, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize |
            ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar);
        drawCanvas(app);
        ImGui::End();

        ImGui::SetNextWindowPos(ImVec2(viewport->WorkPos.x + viewport->WorkSize.x - toolsPanelWidth, viewport->WorkPos.y + topBarHeight));
        ImGui::SetNextWindowSize(ImVec2(toolsPanelWidth, middleHeight));
        ImGui::Begin("Tools", nullptr, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize |
            ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar);
        drawToolsSection(app);
        drawLayersSection(app);
        drawAdjustmentsSection(app);
        drawFiltersSection(app);
        drawTransformSection(app);
        drawHistorySection(app);
        ImGui::End();

        ImGui::SetNextWindowPos(ImVec2(viewport->WorkPos.x, viewport->WorkPos.y + topBarHeight + middleHeight));
        ImGui::SetNextWindowSize(ImVec2(viewport->WorkSize.x, bottomBarHeight));
        ImGui::Begin("BottomBar", nullptr, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize |
            ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar);
        drawBottomBar(app);
        ImGui::End();

        ImGui::Render();
        int display_w, display_h;
        glfwGetFramebufferSize(window, &display_w, &display_h);
        glViewport(0, 0, display_w, display_h);
        glClearColor(0.11f, 0.11f, 0.12f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        glfwSwapBuffers(window);
    }

    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}
