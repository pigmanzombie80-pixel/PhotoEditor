#include "PaintTools.h"
#include <algorithm>
#include <cmath>
#include <vector>
#include <deque>

namespace PaintTools {

void stampBrush(Image& img, const Selection& sel, int cx, int cy, int radius, Color color) {
    int x0 = std::max(0, cx - radius), x1 = std::min(img.width - 1, cx + radius);
    int y0 = std::max(0, cy - radius), y1 = std::min(img.height - 1, cy + radius);
    float feather = std::max(1.0f, radius * 0.35f); // soft edge width for smoother strokes
    for (int y = y0; y <= y1; y++) {
        for (int x = x0; x <= x1; x++) {
            float dx = (float)(x - cx), dy = (float)(y - cy);
            float dist = std::sqrt(dx * dx + dy * dy);
            if (dist > radius) continue;
            if (!sel.contains(x, y)) continue;
            float coverage = 1.0f;
            if (dist > radius - feather) coverage = std::clamp((radius - dist) / feather, 0.0f, 1.0f);
            uint8_t* p = img.at(x, y);
            float srcA = (color.a / 255.0f) * coverage;
            float dstA = p[3] / 255.0f;
            float outA = srcA + dstA * (1.0f - srcA);
            uint8_t srcRGB[3] = { color.r, color.g, color.b };
            for (int c = 0; c < 3; c++) {
                float srcC = srcRGB[c] / 255.0f;
                float dstC = p[c] / 255.0f;
                float outC = outA > 0.0001f ? (srcC * srcA + dstC * dstA * (1.0f - srcA)) / outA : 0.0f;
                p[c] = clampByteF(outC * 255.0f);
            }
            p[3] = clampByteF(outA * 255.0f);
        }
    }
}

void stampEraser(Image& img, const Selection& sel, int cx, int cy, int radius, float strength) {
    strength = std::clamp(strength, 0.0f, 1.0f);
    int x0 = std::max(0, cx - radius), x1 = std::min(img.width - 1, cx + radius);
    int y0 = std::max(0, cy - radius), y1 = std::min(img.height - 1, cy + radius);
    float feather = std::max(1.0f, radius * 0.35f);
    for (int y = y0; y <= y1; y++) {
        for (int x = x0; x <= x1; x++) {
            float dx = (float)(x - cx), dy = (float)(y - cy);
            float dist = std::sqrt(dx * dx + dy * dy);
            if (dist > radius) continue;
            if (!sel.contains(x, y)) continue;
            float coverage = 1.0f;
            if (dist > radius - feather) coverage = std::clamp((radius - dist) / feather, 0.0f, 1.0f);
            uint8_t* p = img.at(x, y);
            p[3] = clampByteF(p[3] * (1.0f - strength * coverage));
        }
    }
}

void floodFill(Image& img, const Selection& sel, int startX, int startY, Color color, int tolerance) {
    if (startX < 0 || startY < 0 || startX >= img.width || startY >= img.height) return;
    if (!sel.contains(startX, startY)) return;

    const uint8_t* startP = img.at(startX, startY);
    int target[4] = { startP[0], startP[1], startP[2], startP[3] };

    auto matches = [&](const uint8_t* p) {
        return std::abs((int)p[0] - target[0]) <= tolerance &&
               std::abs((int)p[1] - target[1]) <= tolerance &&
               std::abs((int)p[2] - target[2]) <= tolerance &&
               std::abs((int)p[3] - target[3]) <= tolerance;
    };

    std::vector<uint8_t> visited((size_t)img.width * img.height, 0);
    std::deque<std::pair<int, int>> queue;
    queue.push_back({ startX, startY });
    visited[(size_t)startY * img.width + startX] = 1;

    while (!queue.empty()) {
        auto [x, y] = queue.front();
        queue.pop_front();
        if (!sel.contains(x, y)) continue;
        uint8_t* p = img.at(x, y);
        if (!matches(p)) continue;
        p[0] = color.r; p[1] = color.g; p[2] = color.b; p[3] = color.a;

        const int dx[4] = { 1, -1, 0, 0 };
        const int dy[4] = { 0, 0, 1, -1 };
        for (int d = 0; d < 4; d++) {
            int nx = x + dx[d], ny = y + dy[d];
            if (nx < 0 || ny < 0 || nx >= img.width || ny >= img.height) continue;
            size_t idx = (size_t)ny * img.width + nx;
            if (visited[idx]) continue;
            visited[idx] = 1;
            queue.push_back({ nx, ny });
        }
    }
}

Color pickColor(const Image& img, int x, int y) {
    if (x < 0 || y < 0 || x >= img.width || y >= img.height) return { 0, 0, 0, 255 };
    const uint8_t* p = img.at(x, y);
    return { p[0], p[1], p[2], p[3] };
}

} // namespace PaintTools
