#pragma once
#include "Image.h"

namespace Editor {
    void adjustBrightness(const Image& src, Image& dst, float brightness);
    void adjustContrast(const Image& src, Image& dst, float contrast);
    void adjustSaturation(const Image& src, Image& dst, float saturation);
    void adjustHue(const Image& src, Image& dst, float hueDegrees);
    void adjustExposure(const Image& src, Image& dst, float stops);
    void adjustGamma(const Image& src, Image& dst, float gamma);

    void toGrayscale(const Image& src, Image& dst);
    void toSepia(const Image& src, Image& dst);
    void invertColors(const Image& src, Image& dst);
    void boxBlur(const Image& src, Image& dst, int radius);
    void gaussianBlur(const Image& src, Image& dst, float sigma);
    void sharpen(const Image& src, Image& dst, float amount);
    void vignette(const Image& src, Image& dst, float strength);

    void flipHorizontal(const Image& src, Image& dst);
    void flipVertical(const Image& src, Image& dst);
    void rotate90(const Image& src, Image& dst);
    void rotate180(const Image& src, Image& dst);
    void rotate270(const Image& src, Image& dst);
    void rotateArbitrary(const Image& src, Image& dst, float degrees);
    void resize(const Image& src, Image& dst, int newWidth, int newHeight);
    void crop(const Image& src, Image& dst, int x, int y, int w, int h);
}
