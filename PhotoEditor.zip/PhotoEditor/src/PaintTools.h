#pragma once
#include "Image.h"
#include "Selection.h"
#include <cstdint>

namespace PaintTools {
    struct Color { uint8_t r, g, b, a; };

    // Stamps a soft, antialiased-edge, alpha-blended circle at (cx,cy) with
    // the given radius onto `img`. The feathered edge (vs. a hard circle)
    // makes dragged strokes look smooth instead of jagged/pixelated.
    void stampBrush(Image& img, const Selection& sel, int cx, int cy, int radius, Color color);

    // Reduces alpha within a soft-edged circular radius (feathered erase).
    void stampEraser(Image& img, const Selection& sel, int cx, int cy, int radius, float strength);

    // Flood-fills the region connected to (x,y) matching its color within tolerance.
    void floodFill(Image& img, const Selection& sel, int x, int y, Color color, int tolerance);

    // Reads the pixel color at (x,y); used by the eyedropper tool.
    Color pickColor(const Image& img, int x, int y);
}
